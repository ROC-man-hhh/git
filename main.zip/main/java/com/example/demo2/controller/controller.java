package com.example.demo2.controller;

import org.springframework.web.bind.annotation.GetMapping;
import org.springframework.web.bind.annotation.RequestMapping;
import org.springframework.web.bind.annotation.RestController;

@RestController
@RequestMapping("/hello")
public class controller {
    @GetMapping
    public String hello()
    {
        return "helloword Spring Boot！这是一个用Spring Boot开发的网站。";
    }

}